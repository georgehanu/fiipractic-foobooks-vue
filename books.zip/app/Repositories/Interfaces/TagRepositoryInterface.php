<?php

namespace App\Repositories\Interfaces;

use App\Moidel\Tag;

interface TagRepositoryInterface
{
    public function all();

}
