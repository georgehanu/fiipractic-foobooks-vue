<?php

namespace App\Repositories\Interfaces;

use App\Moidel\Author;

interface AuthorRepositoryInterface
{
    public function all();

}
